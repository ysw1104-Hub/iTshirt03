﻿# 이 스크립트를 iTshirt-cat, iTshirt-oct와 같은 폴더에 둡니다.
# 읽기 전용 검사입니다. 네트워크, checkout, pull, 설정 변경을 실행하지 않습니다.
# --no-optional-locks는 상태 검사 시 선택적 인덱스 갱신도 막습니다.

Set-StrictMode -Version 2.0

$packageRoot = $PSScriptRoot
$script:checkCount = 0
$script:failureCount = 0
$script:gitPath = $null
$headIds = @{}
$repositoryNames = @('iTshirt-cat', 'iTshirt-oct')
$expectedFiles = @('README.txt', 'tshirt-list.md', 'feature-list.md')

function Write-Check {
    param(
        [bool]$Passed,
        [string]$Label,
        [string]$Detail = ''
    )

    $script:checkCount++
    if ($Passed) {
        Write-Host ('[통과] ' + $Label) -ForegroundColor Green
    }
    else {
        $script:failureCount++
        Write-Host ('[실패] ' + $Label) -ForegroundColor Red
        if ($Detail) {
            Write-Host ('       ' + $Detail)
        }
    }
}

function Invoke-ReadOnlyGit {
    param(
        [string]$RepositoryPath,
        [string[]]$Arguments
    )

    try {
        $commandOutput = @(& $script:gitPath '--no-optional-locks' '-C' $RepositoryPath @Arguments 2>&1)
        $commandExitCode = $LASTEXITCODE
        $commandText = ($commandOutput | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine
        return [pscustomobject]@{
            ExitCode = $commandExitCode
            Text = $commandText
        }
    }
    catch {
        return [pscustomobject]@{
            ExitCode = -1
            Text = $_.Exception.Message
        }
    }
}

Write-Host 'SW응용 실습 결과 읽기 전용 확인'
Write-Host ('검사 위치: ' + $packageRoot)
Write-Host ''

$gitApplication = Get-Command git -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
if ($null -ne $gitApplication) {
    $script:gitPath = $gitApplication.Source
}
Write-Check ($null -ne $script:gitPath) 'Git 실행 파일을 찾을 수 있음' 'Git을 설치한 후 새 PowerShell 창에서 다시 실행하세요. 파일은 변경하지 않았습니다.'

foreach ($repositoryName in $repositoryNames) {
    $repositoryPath = Join-Path $packageRoot $repositoryName
    $gitDirectory = Join-Path $repositoryPath '.git'
    $hasGitDirectory = Test-Path -LiteralPath $gitDirectory -PathType Container
    Write-Check $hasGitDirectory ($repositoryName + ': .git 이력 폴더 존재') '완성 ZIP 전체를 먼저 압축 해제했는지 확인하세요. GitHub 일반 소스 ZIP에는 .git이 없습니다.'

    foreach ($expectedFile in $expectedFiles) {
        $filePath = Join-Path $repositoryPath $expectedFile
        Write-Check (Test-Path -LiteralPath $filePath -PathType Leaf) ($repositoryName + ': ' + $expectedFile + ' 존재')
    }

    if (($null -eq $script:gitPath) -or (-not $hasGitDirectory)) {
        continue
    }

    $headResult = Invoke-ReadOnlyGit $repositoryPath @('rev-parse', '--verify', 'HEAD')
    $headIsValid = ($headResult.ExitCode -eq 0) -and ($headResult.Text.Trim() -match '^[0-9a-fA-F]{40,64}$')
    Write-Check $headIsValid ($repositoryName + ': HEAD 커밋 확인') $headResult.Text
    if ($headIsValid) {
        $headIds[$repositoryName] = $headResult.Text.Trim().ToLowerInvariant()
        Write-Host ('       HEAD: ' + $headIds[$repositoryName])
    }

    $statusResult = Invoke-ReadOnlyGit $repositoryPath @('status', '--porcelain=v1', '--untracked-files=all')
    $isClean = ($statusResult.ExitCode -eq 0) -and [string]::IsNullOrWhiteSpace($statusResult.Text)
    Write-Check $isClean ($repositoryName + ': 미반영 변경 및 미추적 파일 없음') $statusResult.Text

    $countResult = Invoke-ReadOnlyGit $repositoryPath @('rev-list', '--count', 'HEAD')
    $commitCount = 0
    $countIsValid = [int]::TryParse($countResult.Text.Trim(), [ref]$commitCount)
    $hasEnoughCommits = ($countResult.ExitCode -eq 0) -and $countIsValid -and ($commitCount -ge 4)
    $countDetail = if (($countResult.ExitCode -eq 0) -and $countIsValid) { '확인한 커밋 수: ' + $commitCount } else { $countResult.Text }
    Write-Check $hasEnoughCommits ($repositoryName + ': HEAD 이력에 커밋이 4개 이상') $countDetail

    $mainResult = Invoke-ReadOnlyGit $repositoryPath @('rev-parse', '--verify', 'refs/heads/main')
    $mainPointsToHead = $headIsValid -and ($mainResult.ExitCode -eq 0) -and ($mainResult.Text.Trim() -eq $headResult.Text.Trim())
    Write-Check $mainPointsToHead ($repositoryName + ': 로컬 main이 HEAD와 같은 커밋을 가리킴') $mainResult.Text
}

$bothHeadsAvailable = $headIds.ContainsKey('iTshirt-cat') -and $headIds.ContainsKey('iTshirt-oct')
$headsMatch = $bothHeadsAvailable -and ($headIds['iTshirt-cat'] -eq $headIds['iTshirt-oct'])
Write-Check $headsMatch '두 로컬 저장소의 HEAD가 같음' '앞선 HEAD 검사 결과와 두 폴더의 압축 해제 상태를 확인하세요.'

Write-Host ''
$passCount = $script:checkCount - $script:failureCount
Write-Host ('검사 결과: 통과 ' + $passCount + '개 / 실패 ' + $script:failureCount + '개 / 전체 ' + $script:checkCount + '개')
Write-Host '이 검사는 로컬 파일과 Git 상태만 확인합니다. GUI 조작 수행 여부나 온라인 원격 상태를 판정하지 않습니다.'
if ($script:failureCount -gt 0) {
    Write-Host '실패한 항목을 확인하세요. 검사 과정에서 파일이나 Git 설정을 변경하지 않았습니다.' -ForegroundColor Red
    exit 1
}

Write-Host '요청된 로컬 실습 결과 확인 항목이 모두 통과했습니다.' -ForegroundColor Green
exit 0
